CREATE TABLE DimDate (
    dateid INT PRIMARY KEY,
    date DATE,
    Year INT,
    Quarter INT,
    QuarterName VARCHAR(20),
    Month INT,
    MonthName VARCHAR(20),
    Day INT,
    Weekday INT,
    WeekdayName VARCHAR(20)
);


CREATE TABLE DimTruck (
    Truckid INT PRIMARY KEY,
    TruckType VARCHAR(255)
);

CREATE TABLE DimStation (
    Stationid INT PRIMARY KEY,
    City VARCHAR(255)
);

CREATE TABLE FactTrips (
    Tripid INT PRIMARY KEY,
    Dateid INT,
    Stationid INT,
    Truckid INT,
    Wastecollected DECIMAL(10, 2),
    FOREIGN KEY (Dateid) REFERENCES DimDate(Dateid),
    FOREIGN KEY (Stationid) REFERENCES DimStation(Stationid),
    FOREIGN KEY (Truckid) REFERENCES DimTruck(Truckid)
);
